import { Component, signal } from '@angular/core';
import { PatientSearchComponent } from './patient-search/patient-search.component'; // <-- import our search UI

@Component({
  selector: 'app-root',
  standalone: true, // <-- ensure this is marked as standalone
  imports: [PatientSearchComponent], // <-- now App can render PatientSearchComponent
  template: `<app-patient-search></app-patient-search>`, // directly render the search UI
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('patient-search');
}
