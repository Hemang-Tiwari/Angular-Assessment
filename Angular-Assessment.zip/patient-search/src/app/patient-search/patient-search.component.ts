import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface SearchFieldConfig {
  key: string;         // object key in patient record
  displayName: string; // shown label & table header
  symbol: string;      // symbol used in combined search string
  order: number;       // display order
}

@Component({
  selector: 'app-patient-search',
  standalone: true,
  imports: [CommonModule, FormsModule], // Required for *ngFor, *ngIf, and ngModel
  templateUrl: './patient-search.component.html',
  styleUrls: ['./patient-search.component.css']
})

export class PatientSearchComponent implements OnInit {
  // Configurable fields - change this array to change fields, order, symbols, labels
  config: SearchFieldConfig[] = [
    { key: 'firstName', displayName: 'First name', symbol: '/', order: 1 },
    { key: 'lastName', displayName: 'Last name', symbol: '@', order: 2 },
    { key: 'chartNo', displayName: 'Chart no', symbol: '#', order: 3 },
    { key: 'address1', displayName: 'Address 1', symbol: '$', order: 4 }
  ];

  // runtime helpers
  sortedConfig: SearchFieldConfig[] = [];
  fieldValues: { [key: string]: string } = {}; // current values for each field
  searchText: string = '';                    // combined search string (e.g. /John@Doe)
  results: any[] = [];                        // filtered results
  patients: any[] = [];                       // demo data

  ngOnInit(): void {
    // sort config once and initialize empty values
    this.sortedConfig = [...this.config].sort((a, b) => a.order - b.order);
    for (const c of this.sortedConfig) {
      this.fieldValues[c.key] = '';
    }

    // Demo patient data (replace with API call in real app)
    this.patients = [
      { firstName: 'John', lastName: 'Doe', chartNo: '1001', address1: 'New York' },
      { firstName: 'Jane', lastName: 'Smith', chartNo: '1002', address1: 'Boston' },
      { firstName: 'Alice', lastName: 'Johnson', chartNo: '1003', address1: 'San Francisco' },
      { firstName: 'Bob', lastName: 'Brown', chartNo: '1004', address1: 'Delhi' }
    ];

    // initialize results (all)
    this.results = [...this.patients];
  }

  /***** FIELD -> SEARCH TEXT (on Enter pressed in a field) *****/
  onFieldEnter(_field: SearchFieldConfig) {
    // build combined string from the current field values (in configured order)
    this.buildSearchTextFromFields();
    // You could also auto-run performSearch() here if desired.
  }

  buildSearchTextFromFields() {
    // only include fields that have a non-empty value
    this.searchText = this.sortedConfig
      .map(cfg => (this.fieldValues[cfg.key] ? `${cfg.symbol}${this.fieldValues[cfg.key]}` : ''))
      .join('');
  }

  /***** SEARCH BAR -> FIELDS (live as user types in search bar) *****/
  onSearchTextInput() {
    this.parseSearchTextToFields(this.searchText);
  }

  parseSearchTextToFields(text: string) {
    // reset all fields
    for (const cfg of this.sortedConfig) {
      this.fieldValues[cfg.key] = '';
    }

    // create set of symbols for quick lookup
    const symbolToKey = new Map<string, string>();
    for (const cfg of this.sortedConfig) {
      symbolToKey.set(cfg.symbol, cfg.key);
    }
    const symbols = new Set(symbolToKey.keys());

    // iterate through the text and capture symbol-value pairs
    let i = 0;
    while (i < text.length) {
      const ch = text[i];
      if (symbols.has(ch)) {
        const symbol = ch;
        i++;
        const start = i;
        while (i < text.length && !symbols.has(text[i])) {
          i++;
        }
        const value = text.substring(start, i);
        const key = symbolToKey.get(symbol);
        if (key !== undefined) {
          this.fieldValues[key] = value;
        }
      } else {
        // skip stray characters (keeps parser simple)
        i++;
      }
    }
  }

  /***** Search logic (simple client-side filter over demo data) *****/
  performSearch() {
    const cfgs = this.sortedConfig;
    // For this demo, we match case-insensitive 'contains'. If user includes '%' it behaves the same (we strip it).
    this.results = this.patients.filter(patient => {
      return cfgs.every(cfg => {
        const q = (this.fieldValues[cfg.key] || '').trim();
        if (!q) return true; // no filter by this field
        const normalizedQ = q.replace(/%/g, '').toLowerCase();
        const val = String(patient[cfg.key] || '').toLowerCase();
        return val.includes(normalizedQ);
      });
    });
  }

  clearAll() {
    this.searchText = '';
    for (const cfg of this.sortedConfig) this.fieldValues[cfg.key] = '';
    this.results = [...this.patients];
  }
}